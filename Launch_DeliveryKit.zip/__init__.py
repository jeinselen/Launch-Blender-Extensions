import bpy

# Local imports
from . import delivery_panel
from . import io_csv
from . import io_svg
from . import io_splinemaker
from . import utility_panel



###########################################################################
# Global user preferences and UI rendering class

class DeliveryKitPreferences(bpy.types.AddonPreferences):
	bl_idname = __package__
	
	########## Delivery Panel Location ##########
	
	def update_delivery_category(self, context):
		utility_panel.register_panels(delivery_panel.panels)
	
	delivery_category: bpy.props.StringProperty(
		name="3D View",
		description="Choose a 3D view tab category for the panel to be placed in, or leave empty to hide the panel",
		default="Launch",
		update=update_delivery_category)
		# Consider adding search_options=(list of currently available tabs) for easier operation
	
	
	
	############################## Preferences UI ##############################
	
	# User Interface
	def draw(self, context):
		layout = self.layout
		
		########## Delivery Panel ##########
		titlegrid = layout.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=True, align=False)
		titlegrid.label(text="Delivery Interface", icon="FILE") # FILE CURRENT_FILE FILE_BLEND DUPLICATE
		titlegrid.prop(self, "delivery_category", text="", icon="VIEW3D")



###########################################################################
# Local project settings

class DeliveryKitSettings(bpy.types.PropertyGroup):
	file_type: bpy.props.EnumProperty(
		name = 'Pipeline',
		description = 'Sets the format for delivery output',
		items = [
			('FBX-1', 'FBX — Unity 3D', 'Export FBX binary file for Unity 3D'),
			('FBX-2', 'FBX — Unreal Engine', 'Export FBX binary file for Unreal Engine'),
			('GLB', 'GLB — ThreeJS', 'Export GLTF compressed binary file for ThreeJS'),
			('GLTF', 'GLTF — Godot Engine', 'Export GLTF file for Godot Engine'),
			('OBJ', 'OBJ — Element3D', 'Export OBJ file for VideoCopilot Element 3D'),
#			('USDA', 'USDA — Omniverse', 'Export USDZ file for the Nvidia Omniverse platform'),
			('USDZ', 'USDZ — Xcode', 'Export USDZ file for Apple platforms'),
			(None),
			('STL', 'STL — 3D Printing', 'Export individual STL file of each selected object for 3D printing'),
			(None),
			('CSV-1', 'CSV — Points', 'Export vertex positions as CSV data'),
			('CSV-2', 'CSV — Transforms', 'Export object transforms over time as CSV data'),
			('JSON', 'JSON — SplineMaker', 'Export SplineMaker curve data as JSON'),
			('SVG', 'SVG — Rive', 'Export Bézier, NURBS, and poly line curve objects as 2D vectors')
			],
		default = 'FBX-1')
	file_location: bpy.props.StringProperty(
		name = "Delivery Location",
		description = "Delivery location for all exported files",
		subtype = "DIR_PATH",
		options={'OUTPUT_PATH','PATH_SUPPORTS_BLEND_RELATIVE','SUPPORTS_TEMPLATES'},
		default = "//",
		maxlen = 4096)
	file_animation: bpy.props.EnumProperty(
		name = 'Animation',
		description = 'Sets static or animated output',
		items = [
			('STATIC', 'Static', 'Export current frame without animation'),
			('ANIM', 'Animated', 'Export animation within timeline range')
			],
		default = 'STATIC')
	file_grouping: bpy.props.EnumProperty(
		name = 'Grouping',
		description = 'Sets combined or individual file outputs',
		items = [
			('COMBINED', 'Combined', 'Export selection in one file'),
			('INDIVIDUAL', 'Individual', 'Export selection as individual files')
			],
		default = 'COMBINED')
	csv_position: bpy.props.EnumProperty(
		name = 'Position',
		description = 'Sets local or world space coordinates',
		items = [
			('WORLD', 'World', 'World space'),
			('LOCAL', 'Local', 'Local object space')
			],
		default = 'WORLD')



###########################################################################
# Addon registration functions
# •Define classes being registered
# •Define keymap array
# •Registration function
# •Unregistration function

classes = (DeliveryKitPreferences, DeliveryKitSettings,)

keymaps = []



def register():
	# Register classes
	for cls in classes:
		bpy.utils.register_class(cls)

	# Add extension settings reference
	bpy.types.Scene.delivery_kit_settings = bpy.props.PointerProperty(type=DeliveryKitSettings)

	# Register Sub Modules
	delivery_panel.register()
	io_csv.register()
	io_svg.register()
	io_splinemaker.register()



def unregister():
	# Remove keymaps
	for km, kmi in keymaps:
		km.keymap_items.remove(kmi)
	keymaps.clear()

	# Remove Sub Modules
	io_splinemaker.unregister()
	io_svg.unregister()
	io_csv.unregister()
	delivery_panel.unregister()

	# Remove extension settings reference
	del bpy.types.Scene.delivery_kit_settings

	# Deregister classes
	for cls in reversed(classes):
		bpy.utils.unregister_class(cls)



if __package__ == "__main__":
	register()
