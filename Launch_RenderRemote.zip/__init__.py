import atexit
import bpy
from bpy.props import BoolProperty, IntProperty, StringProperty
from .timers import timer_manager
from .file_sync import file_sync_manager
from .network import network_manager, NetworkManager
from .render import render_manager, RenderManager
from .constants import (AUTH_MAX_CHALLENGES, AUTH_PBKDF2_ITERATIONS, INPUT_MANIFEST_FILENAME, PROTOCOL_MAX_MESSAGE_SIZE, is_allowed_lan_ip)
from .local_state import default_remote_cache_directory
from .paths import (FileFilter, PathSecurityError, normalize_relative_path, relative_path_under_root, resolve_under_root)
from .protocol import (ProtocolError, error_response, recv_file, recv_message, send_file, send_message, validate_message)
from .handlers import (cleanup_on_exit, cleanup_on_load_pre, reset_connection_status_on_load, shutdown)
from . import utility_panel
from .ui import (SyncFileInfo, RemoteNodeProperties, RemoteRuntimeState,
	initialize_remote_runtime_state, start_connection_health_monitor,
	REMOTERENDER_OT_StartDiscovery, REMOTERENDER_OT_StopDiscovery,
	REMOTERENDER_OT_ScanNetwork, REMOTERENDER_OT_ConnectNode,
	REMOTERENDER_OT_DisconnectNode, REMOTERENDER_OT_ConnectManual,
	REMOTERENDER_OT_ScanProject, REMOTERENDER_OT_SyncFiles,
	REMOTERENDER_OT_SelectAllSyncFiles, REMOTERENDER_OT_DeselectAllSyncFiles,
	REMOTERENDER_OT_ClearCache, REMOTERENDER_OT_StartRemoteRender,
	REMOTERENDER_OT_CancelRemoteRender, REMOTERENDER_OT_CancelLocalRender,
	REMOTERENDER_PT_MainPanel)



###########################################################################
# Global user preferences

class RenderRemotePreferences(bpy.types.AddonPreferences):
	bl_idname = __package__
	
	def update_remote_category(self, context):
		set_panel_category(self.remote_category)
	
	remote_category: StringProperty(
		name="3D View",
		description="Choose a 3D view tab category for the remote render panel to be placed in, or leave empty to hide the panel",
		default="Launch",
		update=update_remote_category)
		# Consider adding search_options=(list of currently available tabs) for easier operation
	
	def update_remote_passcode(self, context):
		try:
			if self.remote_passcode and is_registered():
				network_manager.configure_authentication(self.remote_passcode)
			elif is_registered():
				shutdown(force=True)
		except Exception as e:
			print(f"Remote render passcode update failed: {e}")
	
	remote_cache_directory: StringProperty(
		name="Cache Directory",
		description="Local directory for caching remote projects",
		subtype='DIR_PATH',
		options={'PATH_SUPPORTS_BLEND_RELATIVE'},
		default=default_remote_cache_directory()
	)
	remote_discovery_port: IntProperty(
		name="Discovery Port",
		default=5001,
		min=1024,
		max=65535,
		description="Port for network discovery"
	)
	remote_communication_port: IntProperty(
		name="Communication Port",
		default=5002,
		min=1024,
		max=65535,
		description="Port for secure communication"
	)
	remote_passcode: StringProperty(
		name="Authentication Passcode",
		description="Global passcode required for connections to this computer",
		subtype='PASSWORD',
		default="",
		update=update_remote_passcode
	)
	
	remote_manual_ip: StringProperty(name="Manual IP", description="Manually enter IP address", default="")
	remote_manual_port: IntProperty(name="Manual Port", description="Port for manual connection", default=5002, min=1024, max=65535)
	remote_connection_password: StringProperty(name="Connection Password", description="Password for connecting to remote node", subtype='PASSWORD', default="")
	remote_allow_scripts: BoolProperty(
		name="Allow Embedded Scripts on Remote Renders",
		description="Run auto-executing Python embedded in .blend files received from remote nodes (scripted-expression drivers, registered text blocks). Leave disabled unless you fully trust every peer — a malicious file could otherwise run arbitrary code on this computer. Enable only if your own scenes rely on Python drivers or in-file scripts",
		default=False)
	
	
	
	############################## Preferences UI ##############################
	
	def draw(self, context):
		layout = self.layout
		
		layout.label(text="Remote", icon="NETWORK_DRIVE") # NETWORK_DRIVE DISK_DRIVE RENDER_ANIMATION
		
		grid = layout.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=False)
		grid.prop(self, "remote_cache_directory", text="")
		grid.prop(self, "remote_category", text="", icon="VIEW3D")
		grid.prop(self, "remote_passcode", text="")
		grid.operator("render_remote.clear_cache", icon='TRASH')
		subrow = grid.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=False)
		subrow.prop(self, "remote_discovery_port", text="")
		subrow.prop(self, "remote_communication_port", text="")
		grid.prop(self, "remote_allow_scripts", icon='ERROR' if self.remote_allow_scripts else 'CHECKMARK')



###########################################################################
# Addon registration functions

_is_registered = False
_atexit_registered = False

classes = (
	RenderRemotePreferences,
	SyncFileInfo,
	RemoteNodeProperties,
	RemoteRuntimeState,
	REMOTERENDER_OT_StartDiscovery,
	REMOTERENDER_OT_StopDiscovery,
	REMOTERENDER_OT_ScanNetwork,
	REMOTERENDER_OT_ConnectNode,
	REMOTERENDER_OT_DisconnectNode,
	REMOTERENDER_OT_ConnectManual,
	REMOTERENDER_OT_ScanProject,
	REMOTERENDER_OT_SyncFiles,
	REMOTERENDER_OT_SelectAllSyncFiles,
	REMOTERENDER_OT_DeselectAllSyncFiles,
	REMOTERENDER_OT_ClearCache,
	REMOTERENDER_OT_StartRemoteRender,
	REMOTERENDER_OT_CancelRemoteRender,
	REMOTERENDER_OT_CancelLocalRender,
)

# Registered from the tab category set in the extension preferences
panels = [REMOTERENDER_PT_MainPanel]

def register():
	global _is_registered, _atexit_registered
	
	if _is_registered:
		return
	
	# Register all classes
	for cls in classes:
		try:
			bpy.utils.register_class(cls)
		except (RuntimeError, ValueError) as e:
			if "already registered" not in str(e):
				raise
	
	# Register panels
	try:
		utility_panel.register_panels(panels)
	except (AttributeError, KeyError):
		pass
	
	# Register transient runtime collections on WindowManager so Render Remote does not dirty .blend files.
	if not hasattr(bpy.types.WindowManager, 'remote_render_discovered_nodes'):
		bpy.types.WindowManager.remote_render_discovered_nodes = bpy.props.CollectionProperty(type=RemoteNodeProperties)
	if not hasattr(bpy.types.WindowManager, 'remote_render_sync_files'):
		bpy.types.WindowManager.remote_render_sync_files = bpy.props.CollectionProperty(type=SyncFileInfo)
	if not hasattr(bpy.types.WindowManager, 'remote_render_state'):
		bpy.types.WindowManager.remote_render_state = bpy.props.PointerProperty(type=RemoteRuntimeState)
	initialize_remote_runtime_state(bpy.context)
	start_connection_health_monitor()
	
	# Register cleanup handlers
	if cleanup_on_exit not in bpy.app.handlers.load_pre:
		bpy.app.handlers.load_pre.append(cleanup_on_exit)
	
	if cleanup_on_load_pre not in bpy.app.handlers.load_pre:
		bpy.app.handlers.load_pre.append(cleanup_on_load_pre)
	
	if reset_connection_status_on_load not in bpy.app.handlers.load_post:
		bpy.app.handlers.load_post.append(reset_connection_status_on_load)
	
	if not _atexit_registered:
		atexit.register(shutdown)
		_atexit_registered = True
	
	_is_registered = True
	print("Remote Render Sync add-on registered")

def unregister():
	global _is_registered, _atexit_registered
	
	shutdown(force=True)
	
	# Remove handlers
	if cleanup_on_exit in bpy.app.handlers.load_pre:
		bpy.app.handlers.load_pre.remove(cleanup_on_exit)
	
	if cleanup_on_load_pre in bpy.app.handlers.load_pre:
		bpy.app.handlers.load_pre.remove(cleanup_on_load_pre)
	
	if reset_connection_status_on_load in bpy.app.handlers.load_post:
		bpy.app.handlers.load_post.remove(reset_connection_status_on_load)
	
	if _atexit_registered:
		try:
			atexit.unregister(shutdown)
		except (AttributeError, ValueError):
			pass
		_atexit_registered = False
	
	# Unregister panels
	utility_panel.unregister_panels(panels)
	
	# Remove transient runtime collections
	if hasattr(bpy.types.WindowManager, 'remote_render_discovered_nodes'):
		del bpy.types.WindowManager.remote_render_discovered_nodes
	if hasattr(bpy.types.WindowManager, 'remote_render_sync_files'):
		del bpy.types.WindowManager.remote_render_sync_files
	if hasattr(bpy.types.WindowManager, 'remote_render_state'):
		del bpy.types.WindowManager.remote_render_state
	
	# Unregister classes
	for cls in reversed(classes):
		try:
			bpy.utils.unregister_class(cls)
		except RuntimeError:
			pass
		except ValueError:
			pass
	
	_is_registered = False
	print("Remote Render Sync add-on unregistered")

def is_registered():
	"""Return whether Render Remote UI/runtime hooks are registered."""
	return _is_registered

def set_panel_category(category):
	"""Update the 3D View panel category without registering Render Remote when disabled."""
	if not _is_registered:
		REMOTERENDER_PT_MainPanel.bl_category = category
		return
	
	utility_panel.register_panels(panels)

if __package__ == "__main__":
	register()
